---
name: rwa-logo-vi
description: Uptick RWA 品牌 logo 与 upbao 子图案使用规范（VI）。帮非设计同事选对 logo、避免把主 logo 改成金色渐变、避免把 upbao 压成单色、避免改色/拉伸等误用。
---

# RWA Logo VI

让没有设计背景的同事，也能快速选对、用对 Uptick RWA 品牌 logo 和 upbao 子图案，避免改色、拉伸、乱用金色渐变等常见误用。

## 触发场景

- 同事问 "RWA 的 logo 在哪里？"
- "深色背景用哪个版本？"
- "这个 upbao 图案能不能改成单色？"
- "印刷用什么格式？"
- "能不能拉伸 / 改色 / 加投影？"

## 应答原则

1. **先判断他要的是「主 logo」还是「upbao 子图案」**：
   - 主 logo（横版字标 / 螺旋图形标）是黑白单色，不是渐变。
   - upbao 是钱袋子吉祥物，使用金色渐变 `#CAB37C → #A78D4B`。
2. **按背景深浅给对应版本**：浅底→黑版，深底→白版。
3. **禁止行为要直接说死**：改色、拉伸、压单色、加滤镜、拆散重组。
4. **优先给出本 skill `assets/` 目录下对应的标准文件**。

## 核心规则速查

- 主 logo：黑白单色，可自然反白，不要加金色渐变。
- upbao：金色渐变，不要压成单色，不要换渐变方向。
- 安全区域：主 logo ≥ 图形高度 1/4；upbao ≥ 钱袋高度 1/5。
- 最小尺寸：横版字标 ≥ 120px，图形标/upbao ≥ 48px。

## assets 文件对应表

| 场景 | 文件 |
|---|---|
| 白底/浅灰底官网、文档、PPT | `assets/rwa-logo-horizontal-standard.{svg,png,pdf}` |
| 黑底/深底官网、暗色 PPT | `assets/rwa-logo-horizontal-white.{svg,png,pdf}` |
| App 图标、favicon、头像、水印 | `assets/rwa-logo-square-mark-standard.{svg,png,pdf}` |
| 深底图标/头像 | `assets/rwa-logo-square-mark-white.{svg,png,pdf}` |
| 运营活动、吉祥物、红包/福袋 | `assets/rwa-logo-square-upbao-standard.{svg,png,pdf}` |
| 深底运营活动 | `assets/rwa-logo-square-upbao-white.{svg,png,pdf}` |

详细规则见 `references/logo-guidelines.md`。
