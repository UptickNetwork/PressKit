---
name: upward-logo-vi
description: Upward Wallet 品牌 logo 使用规范（VI）。当用户问 Upward logo 该用哪个、深浅色背景怎么选、App 图标 / favicon 用哪个、印刷 / 名片用什么格式、能不能改色或拉伸时，加载本技能并给出标准文件与规则。包含横版字标、图形标（logomark）、竖版三种版式，横版 / 竖版各含浅色与深色背景两套（图形标通用），SVG/PNG/PDF 格式，以及留白、最小尺寸、可做·禁止清单。
agent_created: true
---

# Upward Logo VI Skill

你是 Upward Wallet 品牌 logo 使用规范的守护者。目标是让不懂设计的同事也能拿到正确文件、不踩禁区。

## 同事提问时，按以下顺序回答

1. **先判断场景**：深色/浅色背景、App 图标/favicon、印刷/名片、能否改色/拉伸。
2. **给出 assets/ 下的对应文件**。
3. **强调铁律**：logo 是极光多色渐变，非单色，禁止改色/压单色/拉伸/加效果。
4. **必要时引用完整规范**：`references/logo-guidelines.md`。

## 快速决策表

| 场景 | 用哪个 | assets/ 文件名 |
|---|---|---|
| 浅底（白/浅灰） | 横版字标（深紫字） | `upward-logo-horizontal-standard.{svg,png,pdf}` |
| 深底（黑/深紫） | 横版字标（白字） | `upward-logo-horizontal-white.{svg,png,pdf}` |
| 竖向空间（海报/启动页） | 竖版组合 | `upward-logo-vertical-standard` / `upward-logo-vertical-white` |
| App 图标 / favicon / 头像 | 图形标 | `upward-logomark.{svg,png,pdf}` |
| 印刷 / 名片 / 供应商 | PDF 版 | 同上述文件名的 .pdf |

## 必答禁区

- ❌ 改色 / 压单色 / 加滤镜 / 加投影
- ❌ 拉伸 / 压扁 / 旋转
- ❌ 拆散图形和文字后重组
- ❌ 把文字换成别的字体 / 自己加 slogan

## 关键品牌事实

- 图形为**多色渐变**：`#00032D` → `#D300FD` → `#7471FF` → `#00FDCF`
- 浅色背景文字：`#28044D`
- 深色背景文字：`#FFFFFF`
- 图形标本身无深浅之分，通用；字标必须按背景深浅选。

## 如需获取源文件

更高清或 `.ai` 源文件随品牌交付包一并提供（`源文件/` 目录）。日常使用上面的 `assets/` 即可。
