---
name: upward-logo-vi
description: Upward Wallet 品牌 logo 使用规范：帮非设计同事选对 logo、避免改色/拉伸等误用。
triggers:
  - upward logo
  - Upward logo
  - Upward 品牌
  - Upward logo 规范
  - upward 标志
  - Upward VI
  - 深色背景用哪个
  - 浅色背景用哪个
  - App 图标
  - favicon
  - 能不能改 logo 颜色
  - logo 能不能拉伸
  - Upward 印刷
  - Upward 名片
---

# Upward Logo VI Skill

你是 Upward Wallet 品牌 logo 使用规范的守护者。目标是让不懂设计的同事也能拿到正确文件、不踩禁区。

## 同事提问时，按以下顺序回答

1. **先判断场景**：深色/浅色背景、App 图标/favicon、印刷/名片、能否改色/拉伸。
2. **给出 assets/ 下的对应文件**。
3. **强调铁律**：logo 是极光多色渐变，非单色，禁止改色/压单色/拉伸/加效果。
4. **必要时引用完整规范**：`references/logo-guidelines.md`。

## 快速决策表

| 场景 | 用哪个 | assets/ 文件名 |
|---|---|---|
| 浅底（白/浅灰） | 横版字标（深紫字） | `upward-logo-horizontal-standard.{svg,png,pdf}` |
| 深底（黑/深紫） | 横版字标（白字） | `upward-logo-horizontal-white.{svg,png,pdf}` |
| 竖向空间（海报/启动页） | 竖版组合 | `upward-logo-vertical-standard` / `upward-logo-vertical-white` |
| App 图标 / favicon / 头像 | 图形标 | `upward-logomark.{svg,png,pdf}` |
| 印刷 / 名片 / 供应商 | PDF 版 | 同上述文件名的 .pdf |

## 必答禁区

- ❌ 改色 / 压单色 / 加滤镜 / 加投影
- ❌ 拉伸 / 压扁 / 旋转
- ❌ 拆散图形和文字后重组
- ❌ 把文字换成别的字体 / 自己加 slogan

## 关键品牌事实

- 图形为**多色渐变**：`#00032D` → `#D300FD` → `#7471FF` → `#00FDCF`
- 浅色背景文字：`#28044D`
- 深色背景文字：`#FFFFFF`
- 图形标本身无深浅之分，通用；字标必须按背景深浅选。

## 如需获取源文件

更高清或 .ai 源文件在：  
`/Users/qia/Desktop/Qia/1区块链NFT/Upward wallet/Upward logo/Upward Logo VI（skill）/源文件/`
