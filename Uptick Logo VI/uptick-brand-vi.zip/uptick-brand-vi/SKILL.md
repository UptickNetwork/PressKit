---
name: uptick-brand-vi
description: Uptick 品牌 logo 使用规范（VI），含 App 紫色渐变与 Web Marketplace 极光渐变两条产品线。当用户问 Uptick logo 该用哪个版本、App 线与 Web Marketplace 线的颜色有什么区别、深色背景用哪个、能不能改色或拉伸、该用 svg 还是 png 时，加载本技能并给出标准文件与规则。包含两条产品线各自的横版字标、图形标、竖版三种版式，浅色 / 深色背景两套，SVG/PNG/PDF 格式，以及两线颜色系统不可混用的铁律、留白、最小尺寸、可做·禁止清单。
agent_created: true
---

# Uptick Logo VI

让没有设计背景的同事也能正确选用 Uptick logo。核心规则：**先选平台（App 线 / Web Marketplace 线），再选背景（浅底 / 深底），然后拿对应文件**。

## 品牌事实

Uptick 品牌包含两条产品线，**颜色系统不同，必须按平台选用**：

### App 端（Uptick App / NFT / 移动端生态）
- 图形标：紫色渐变 `#553dde → #842bde → #df6fff`
- 浅色背景字标：深紫渐变 `#270645 → #4c1083`
- 深色背景字标：白→浅薰衣草 `#ffffff → #e4ddfe`
- 调性：NFT/加密/应用，稳重紫

### Web 端 Marketplace（Uptick Marketplace / 网页端）
- 图形标：极光渐变 `#00032D → #D300FD → #7471FF → #00FDCF`
- 浅色背景字标：深紫渐变 `#270645 → #4c1083`
- 深色背景字标：纯白 `#ffffff`
- 调性：Web3 市场/开放/活力，带青色的极光感

**核心铁律：两条线的颜色系统不能互换。App 端不要用 Marketplace 极光色，Web 端不要用 App 纯紫渐变。**

---

## 决策树

1. **先问平台**：是 Uptick App/移动端生态？还是 Uptick Marketplace/网页端？
   - App → 紫色渐变线（文件命名以 `uptick-app-*` 开头）
   - Web Marketplace → 极光渐变线（文件命名以 `uptick-web-marketplace-*` 开头）
2. **再问背景**：浅底还是深底？
   - 浅底 → `*-standard`
   - 深底 → `*-white`
3. **最后选变体**：`horizontal` 横版 / `vertical` 竖版 / `logomark` 图形标

---

## 可用文件

所有文件在 `assets/` 下，命名规则：

```
uptick-{app|web-marketplace}-logo-{horizontal|vertical|logomark}-{standard|white}.{svg|png|pdf}
```

### App 线
- `uptick-app-logo-horizontal-standard`
- `uptick-app-logo-horizontal-white`
- `uptick-app-logo-vertical-standard`
- `uptick-app-logo-vertical-white`
- `uptick-app-logomark`

### Web Marketplace 线
- `uptick-web-marketplace-logo-horizontal-standard`
- `uptick-web-marketplace-logo-horizontal-white`
- `uptick-web-marketplace-logo-vertical-standard`
- `uptick-web-marketplace-logo-vertical-white`
- `uptick-web-marketplace-logomark`

---

## 永远禁止

- 把 App 紫色和 Web 极光混用
- 自行改色、压单色、拉伸、旋转、加效果
- 把深色背景版放浅底、浅色背景版放深底
- 小于最小尺寸仍用横版字标

详细规则见 `references/logo-guidelines.md`。
